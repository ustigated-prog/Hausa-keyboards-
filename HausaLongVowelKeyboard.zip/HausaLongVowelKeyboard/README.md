# Hausa Long Vowel Keyboard (Android IME, Kotlin)

## Build
1. Install Android Studio (Koala or newer, JDK 17 bundled).
2. File > Open > select this folder; let Gradle sync (needs internet once).
3. Build > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
   (or terminal: `./gradlew assembleDebug` after Android Studio creates the wrapper)
4. Copy the APK to your phone and install (allow "unknown sources"), or run from Android Studio with USB debugging.
5. Open the app: "1. Enable keyboard" -> switch on; "2. Choose keyboard" -> select it.

## Layout
- Number row, QWERTY. Long-press: a e i o u -> ā ē ī ō ū; b d k y -> ɓ ɗ ƙ ƴ; ' -> ʼ
  (green hint shown on each key). Shift (⇧) gives Ā Ɓ Ɗ Ƙ Ƴ etc.
- Tabs: ABC | LONG VOWELS (ā ē ī ō ū / Ā Ē Ī Ō Ū) | SYLLABLES (11 onsets x 5 long vowels,
  scrollable, Shift capitalises: Gwā) | CUSTOM (user-defined, set in the app).
- After inserting from LONG VOWELS / SYLLABLES it returns to ABC (AUTO_RETURN in HausaImeService.kt).

## Unicode
All long vowels are precomposed NFC: ā U+0101 ē U+0113 ī U+012B ō U+014D ū U+016B;
Ā U+0100 Ē U+0112 Ī U+012A Ō U+014C Ū U+016A. ɓ U+0253 Ɓ U+0181 ɗ U+0257 Ɗ U+018A
ƙ U+0199 Ƙ U+0198 ƴ U+01B4 Ƴ U+01B3 ʼ U+02BC. Syllables like ƙā are ƙ + precomposed ā, so no
combining marks (U+0304) are ever inserted. Custom characters are NFC-normalised on save.

## Test checklist
Settings-app test field, Messages, WhatsApp (type, send, check receiver), Notes, Chrome, copy/paste round trip.
Check: macron centred on the vowel, no gap/overlap after ɓ ɗ ƙ, backspace removes one visible vowel,
Enter sends/new-lines properly.

## Known limitations
- ɓ/ɗ/ƙ + combining macron have no precomposed form; if you type them that way, rendering depends on the
  font (the in-app "combining fallback" line shows how your phone does). This keyboard avoids it.
- Some apps/fonts (older Android, custom fonts) may lack Ɓ Ɗ Ƙ Ƴ glyphs and show boxes.
- No word prediction / dark theme yet.
