package ng.hausa.longvowel

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun tv(t: String, sp: Float = 15f) = TextView(this).apply {
            text = t; textSize = sp; setPadding(0, pad / 2, 0, pad / 4)
        }

        col.addView(tv("Hausa Long Vowel Keyboard", 22f))
        col.addView(tv("Step 1: enable the keyboard. Step 2: select it. Then use LONG VOWELS, SYLLABLES and CUSTOM tabs, or long-press a, e, i, o, u, b, d, k, y."))

        col.addView(Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "2. Choose keyboard"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        col.addView(tv("Test field:"))
        col.addView(EditText(this).apply { hint = "Type here"; textSize = 22f })

        col.addView(tv("Rendering test (check every macron sits correctly):"))
        col.addView(TextView(this).apply {
            textSize = 24f
            text = "ā ē ī ō ū  Ā Ē Ī Ō Ū\n" +
                "ɓā ɗē ƙī ɓō ɗū ƙū\n" +
                "ƙwā ƙyē gwī gyō kwū kyā tsē shī\n" +
                "Ɓ Ɗ Ƙ ƴ Ƴ \u02BC\n" +
                "combining fallback: ɓ\u0304 ɗ\u0304 ƙ\u0304"
        })

        col.addView(tv("Custom characters (separate with spaces):"))
        val et = EditText(this).apply {
            setText(Chars.custom(this@SettingsActivity).joinToString(" "))
            textSize = 20f
        }
        col.addView(et)
        col.addView(Button(this).apply {
            text = "Save custom characters"
            setOnClickListener {
                Chars.saveCustom(this@SettingsActivity, et.text.toString())
                Toast.makeText(this@SettingsActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
