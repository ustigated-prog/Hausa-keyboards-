package ng.hausa.longvowel

import android.content.Context
import java.text.Normalizer

/** All characters are precomposed NFC code points (no combining marks needed). */
object Chars {
    val LONG_LOWER = listOf("\u0101", "\u0113", "\u012B", "\u014D", "\u016B") // ā ē ī ō ū
    val LONG_UPPER = listOf("\u0100", "\u0112", "\u012A", "\u014C", "\u016A") // Ā Ē Ī Ō Ū
    val ONSETS = listOf("ɓ", "ɗ", "ƙ", "gw", "gy", "kw", "ky", "ƙw", "ƙy", "ts", "sh")

    /** Long-press alternates on the letter keyboard. */
    val ALT = mapOf(
        'a' to "ā", 'e' to "ē", 'i' to "ī", 'o' to "ō", 'u' to "ū",
        'b' to "ɓ", 'd' to "ɗ", 'k' to "ƙ", 'y' to "ƴ", '\'' to "\u02BC"
    )

    const val DEFAULT_CUSTOM = "\u02BC ƴ Ƴ à è ì ò ù â ê î ô û"
    private const val PREFS = "hausa_ime"
    private const val KEY = "custom"

    fun custom(c: Context): List<String> =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, DEFAULT_CUSTOM)!!
            .split(Regex("[\\s,]+")).filter { it.isNotEmpty() }

    fun saveCustom(c: Context, raw: String) {
        val nfc = Normalizer.normalize(raw, Normalizer.Form.NFC)
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, nfc).apply()
    }
}
