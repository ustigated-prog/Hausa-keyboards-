package ng.hausa.longvowel

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class HausaImeService : InputMethodService() {

    private enum class Mode { LETTERS, LONG, SYLL, CUSTOM }

    private var mode = Mode.LETTERS
    private var shift = false
    private var root: LinearLayout? = null
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreateInputView(): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setBackgroundColor(BG)
        r.setPadding(dp(3), dp(3), dp(3), dp(3))
        root = r
        render()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        mode = Mode.LETTERS
        shift = false
        render()
    }

    // ---------- rendering ----------

    private fun render() {
        val r = root ?: return
        r.removeAllViews()
        r.addView(tabs(), LinearLayout.LayoutParams(MATCH_PARENT, dp(40)))
        val body = when (mode) {
            Mode.LETTERS -> lettersPanel()
            Mode.LONG -> longPanel()
            Mode.SYLL -> syllPanel()
            Mode.CUSTOM -> customPanel()
        }
        r.addView(body, LinearLayout.LayoutParams(MATCH_PARENT, dp(192)))
        r.addView(bottomRow(), LinearLayout.LayoutParams(MATCH_PARENT, dp(48)))
    }

    private fun tabs(): View {
        val ks = mutableListOf<View>()
        fun tab(label: String, m: Mode, w: Float) = key(
            label, w, 12f,
            if (mode == m) ACCENT else SPECIAL,
            if (mode == m) Color.WHITE else Color.BLACK
        ) { mode = m; render() }
        ks += tab("ABC", Mode.LETTERS, 0.8f)
        ks += tab("LONG VOWELS", Mode.LONG, 1.6f)
        ks += tab("SYLLABLES", Mode.SYLL, 1.3f)
        ks += tab("CUSTOM", Mode.CUSTOM, 1.1f)
        if (mode != Mode.LETTERS) ks += shiftKey(0.7f)
        return row(ks, dp(40))
    }

    private fun shiftKey(w: Float) = key(
        "\u21E7", w, 20f,
        if (shift) ACCENT else SPECIAL,
        if (shift) Color.WHITE else Color.BLACK
    ) { shift = !shift; render() }

    private fun lettersPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(row("1234567890".map { c -> key(c.toString(), 1f, 16f) { commit(c.toString()) } }))
        col.addView(row("qwertyuiop".map { letterKey(it) }))
        col.addView(row("asdfghjkl".map { letterKey(it) }))
        val r3 = mutableListOf<View>(shiftKey(1.5f))
        "zxcvbnm'".forEach { r3 += letterKey(it) }
        col.addView(row(r3))
        return col
    }

    private fun letterKey(ch: Char): Button {
        val alt = Chars.ALT[ch]
        val base = show(ch.toString())
        val label: CharSequence = if (alt == null) base else hinted(base, show(alt))
        return key(label, 1f, 18f, onLong = alt?.let { a -> { commitChar(show(a)) } }) { commitChar(base) }
    }

    private fun longPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        for (set in listOf(Chars.LONG_LOWER, Chars.LONG_UPPER)) {
            col.addView(row(set.map { v -> key(v, 1f, 30f) { commit(v); afterPanel() } }))
        }
        return col
    }

    private fun syllPanel(): View {
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        for (on in Chars.ONSETS) {
            val o = if (shift) on.replaceFirstChar { it.uppercase() } else on
            inner.addView(row(Chars.LONG_LOWER.map { v ->
                val s = o + v
                key(s, 1f, 22f) { commit(s); afterPanel() }
            }, dp(48)))
        }
        val sv = ScrollView(this)
        sv.addView(inner)
        return sv
    }

    private fun customPanel(): View {
        val items = Chars.custom(this)
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = "No custom characters yet.\nAdd them in the Hausa Long Vowel Keyboard app."
            t.setPadding(dp(12), dp(12), dp(12), dp(12))
            return t
        }
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        items.chunked(6).forEach { chunk ->
            val ks = chunk.map { s -> key(s, 1f, 22f) { commit(s) } }.toMutableList<View>()
            while (ks.size < 6) ks += View(this).apply { layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f) }
            inner.addView(row(ks, dp(48)))
        }
        val sv = ScrollView(this)
        sv.addView(inner)
        return sv
    }

    private fun bottomRow(): View = row(listOf(
        key(",", 1f, 18f) { commit(",") },
        key("space", 4f, 14f) { commit(" ") },
        key(".", 1f, 18f) { commit(".") },
        backKey(),
        key("\u23CE", 1.5f, 20f, SPECIAL) { enter() }
    ), dp(48))

    // ---------- input actions ----------

    private fun show(s: String) = if (shift) s.uppercase() else s

    private fun commit(s: String) { currentInputConnection?.commitText(s, 1) }

    private fun commitChar(s: String) {
        commit(s)
        if (shift) { shift = false; render() }
    }

    /** After a long-vowel / syllable insert, go back to the letter keyboard. */
    private fun afterPanel() {
        if (AUTO_RETURN) { mode = Mode.LETTERS }
        shift = false
        render()
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1)
        else ic.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun backKey(): Button {
        val b = key("\u232B", 1.5f, 20f, SPECIAL) { }
        val rep = object : Runnable {
            override fun run() { backspace(); ui.postDelayed(this, 50) }
        }
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; backspace(); ui.postDelayed(rep, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; ui.removeCallbacks(rep) }
            }
            true
        }
        return b
    }

    // ---------- view helpers ----------

    private fun hinted(base: String, alt: String): CharSequence {
        val sb = SpannableStringBuilder(base).append(" ")
        val start = sb.length
        sb.append(alt)
        sb.setSpan(RelativeSizeSpan(0.55f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(ACCENT), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun shape(c: Int) = GradientDrawable().apply {
        cornerRadius = dp(6).toFloat()
        setColor(c)
    }

    private fun key(
        label: CharSequence, w: Float = 1f, size: Float = 18f,
        color: Int = KEY, fg: Int = Color.BLACK,
        onLong: (() -> Unit)? = null, onTap: () -> Unit
    ): Button {
        val b = Button(this)
        b.text = label
        b.textSize = size
        b.isAllCaps = false
        b.setTextColor(fg)
        b.minWidth = 0; b.minimumWidth = 0; b.minHeight = 0; b.minimumHeight = 0
        b.setPadding(0, 0, 0, 0)
        b.stateListAnimator = null
        b.background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(PRESSED))
            addState(intArrayOf(), shape(color))
        }
        b.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, w).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
        b.setOnClickListener { onTap() }
        if (onLong != null) b.setOnLongClickListener { onLong(); true }
        return b
    }

    private fun row(views: List<View>, h: Int = 0): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        views.forEach { l.addView(it) }
        l.layoutParams = if (h > 0) LinearLayout.LayoutParams(MATCH_PARENT, h)
        else LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f)
        return l
    }

    companion object {
        /** true = return to ABC after inserting from LONG VOWELS / SYLLABLES. */
        const val AUTO_RETURN = true
        val BG = 0xFFE3E6EA.toInt()
        val KEY = 0xFFFFFFFF.toInt()
        val SPECIAL = 0xFFBCC3CE.toInt()
        val PRESSED = 0xFF9FB0C8.toInt()
        val ACCENT = 0xFF2E7D32.toInt()
    }
}
